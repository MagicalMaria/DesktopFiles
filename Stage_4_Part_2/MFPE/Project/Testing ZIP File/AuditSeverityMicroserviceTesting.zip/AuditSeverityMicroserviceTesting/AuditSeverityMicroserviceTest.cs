using AuditSeverityMicroservice.Controllers;
using AuditSeverityMicroservice.Models;
using AuditSeverityMicroservice.Repositories;
using AuditSeverityMicroservice.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace AuditSeverityMicroserviceTesting
{
    public class Tests
    {
        List<AuditResponse> AuditResponseDetails = new List<AuditResponse>();
        [SetUp]
        public void Setup()
        {
            AuditResponseDetails = new List<AuditResponse>()
            {
                new AuditResponse
                {
                    ProjectExecutionStatus="GREEN",
                    RemedialActionDuration="No Action Needed"
                },
                new AuditResponse
                {
                    ProjectExecutionStatus="RED",
                    RemedialActionDuration="Action to be taken in 2 weeks"
                },
                new AuditResponse
                {
                    ProjectExecutionStatus="RED",
                    RemedialActionDuration="Action to be taken in 1 week"
                }
            };
        }

        [Test]
        public void Internal_GetServiceResponseTest()
        {
            Mock<IProjectExecutionStatusRepository> mock = new Mock<IProjectExecutionStatusRepository>();
            mock.Setup(p => p.AuditResponseDetails()).Returns(AuditResponseDetails);
            ProjectExecutionStatusService service = new ProjectExecutionStatusService(mock.Object);
            AuditRequest req = new AuditRequest
            {
                AuditDetails = new AuditDetail
                {
                    Type = "Internal",
                    Questions = new Questions
                    {
                        Question1 = true,
                        Question2 = false,
                        Question3 = false,
                        Question4 = false,
                        Question5 = true
                    }
                }
            };

            AuditResponse result = service.GetProjectExecutionStatusData(req);

            Assert.AreEqual("GREEN",result.ProjectExecutionStatus);
        }

        [Test]
        public void SOX_GetServiceResponseTest()
        {
            Mock<IProjectExecutionStatusRepository> mock = new Mock<IProjectExecutionStatusRepository>();
            mock.Setup(p => p.AuditResponseDetails()).Returns(AuditResponseDetails);
            ProjectExecutionStatusService service = new ProjectExecutionStatusService(mock.Object);
            AuditRequest req = new AuditRequest
            {
                AuditDetails = new AuditDetail
                {
                    Type = "Internal",
                    Questions = new Questions
                    {
                        Question1 = true,
                        Question2 = false,
                        Question3 = false,
                        Question4 = false,
                        Question5 = false
                    }
                }
            };

            AuditResponse result = service.GetProjectExecutionStatusData(req);

            Assert.AreEqual("RED", result.ProjectExecutionStatus);
        }

        [TestCase("Internal")]
        [TestCase("SOX")]
        public void PassTest_ProjectExecutionStatusController(string type)
        {
            Mock<IProjectExecutionStatusService> mock = new Mock<IProjectExecutionStatusService>();
            //AuditResponse res = new AuditResponse();
            AuditRequest req = new AuditRequest
            {
                AuditDetails = new AuditDetail
                {
                    Type = type,
                    Questions = new Questions
                    {
                        Question1 = true,
                        Question2 = false,
                        Question3 = false,
                        Question4 = false,
                        Question5 = false
                    }
                }
            };
            //mock.Setup(p => p.GetProjectExecutionStatusData(req)).Returns(res);
            ProjectExecutionStatusController controller = new ProjectExecutionStatusController(mock.Object);
            OkObjectResult result = controller.Post(req) as OkObjectResult;

            Assert.AreEqual(200, result.StatusCode);
        }

        [TestCase("Internal123")]
        [TestCase("SOX123")]
        public void FailTest_ProjectExecutionStatusController(string type)
        {
            try
            {
                Mock<IProjectExecutionStatusService> mock = new Mock<IProjectExecutionStatusService>();
                //AuditResponse res = new AuditResponse();
                AuditRequest req = new AuditRequest
                {
                    AuditDetails = new AuditDetail
                    {
                        Type = type,
                        Questions = new Questions
                        {
                            Question1 = true,
                            Question2 = false,
                            Question3 = false,
                            Question4 = false,
                            Question5 = false
                        }
                    }
                };
                //mock.Setup(p => p.GetProjectExecutionStatusData(req)).Returns(res);
                ProjectExecutionStatusController controller = new ProjectExecutionStatusController(mock.Object);
                OkObjectResult result = controller.Post(req) as OkObjectResult;

               // Assert.AreEqual(200, result.StatusCode);
            }
            catch(Exception e)
            {
                Assert.AreEqual("Object reference not set to an instance of an object.", e.Message);
            }
        }
    }
}